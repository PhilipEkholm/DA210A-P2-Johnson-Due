/*
 * consoleFunctions.h
 *
 * Created: 2015-06-12 16:47:11
 *  Author: Ulrik
 */ 


#ifndef CONSOLEFUNCTIONS_H_
#define CONSOLEFUNCTIONS_H_

void configureConsole(void);

#endif /* CONSOLEFUNCTIONS_H_ */